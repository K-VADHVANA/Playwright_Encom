'use strict';
(function ()
{
    var MESSAGE_NAMESPACE = 'cross-domain';
    var ALLOWED_DOMAIN = true;
    var ISOLATED = {}; // Not allowed domains will "work", but nothing will be saved oustide this script

    function hasToUseFallBack()
    {
        // by default, third party localstorage is disabled on safari
        // fall back to third party cookies, since that works (after a cookie has already been set by the domain when not in an iframe)
        return isIosSafari() || isDesktopSafari() || !ALLOWED_DOMAIN;
    }

    function isIosSafari()
    {
        return /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
    }

    function isDesktopSafari()
    {
        return /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
    }

    function postData(id, data)
    {
        var mergedData = {};
        mergedData.namespace = MESSAGE_NAMESPACE;
        mergedData.value = data;
        mergedData.id = id;
        parent.postMessage(mergedData, '*');
    }

    function getItem(id, key)
    {
        var value = hasToUseFallBack() ? getCookie(key) : localStorage.getItem(key);
        postData(id, value);
    }

    function getItems(id, keys)
    {
        var data = {};

        for (var i = 0, len = keys.length; i < len; ++i)
        {
            var value = hasToUseFallBack() ? getCookie(keys[i]) : localStorage.getItem(keys[i]);
            data[keys[i]] = value;
        }
        postData(id, data);
    }

    function setItem(id, key, value)
    {
        if (hasToUseFallBack())
            setCookie(key, value, 365);
        if (ALLOWED_DOMAIN) localStorage.setItem(key, value);
        postData(id, null);
    }

    function setItems(id, keys, values)
    {
        for (var i = 0, len = keys.length; i < len; ++i)
        {
            if (hasToUseFallBack())
                setCookie(keys[i], values[i], 365);
            if (ALLOWED_DOMAIN) localStorage.setItem(keys[i], values[i]);
        }
        postData(id, null);
    }

    function removeItem(id, key)
    {
        if (hasToUseFallBack())
            removeCookie(key);
        else
            localStorage.removeItem(key);
        postData(id, null);
    }

    function removeItems(id, keys)
    {
        for (var i = 0, len = keys.length; i < len; ++i)
        {
            if (hasToUseFallBack())
                removeCookie(keys[i]);
            else
                localStorage.removeItem(keys[i]);
        }
        postData(id, null);
    }

    function getKey(id, index)
    {
        var key;
        if (hasToUseFallBack())
            key = getCookieKeys()[index];
        else
            key = localStorage.key(index);
        postData(id, key);
    }

    function getLength(id)
    {
        var length;
        if (hasToUseFallBack())
            key = getCookieKeys().length;
        else
            length = localStorage.length;
        postData(id, length);
    }

    function clear(id)
    {
        if (hasToUseFallBack())
        {
            var keys = getCookieKeys();
            for (var i = 0, len = keys.length; i < len; ++i)
            {
                removeCookie(keys[i]);
            }
        }
        else
            localStorage.clear();
        postData(id, null);
    }



    function setCookie(cname, cvalue, exdays)
    {
        if (ALLOWED_DOMAIN)
        {
            if (cvalue === undefined || cvalue === null)
            {
                cvalue = '';
                exdays = -1;
            }
            var d = new Date();
            d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
            var expires = "expires=" + d.toUTCString();

            var cookieString = cname + "=" + encodeURIComponent(cvalue) + ";" + expires + ";path=/";

            // Set flags for browsers that support (and require) them for cross-domain usage.
            document.cookie = cookieString + ";Secure;SameSite=None";

            // Set a legacy cookie that omits supported flags.
            document.cookie = cookieString.replace(cname + "=", cname + "_legacy=");
        } else ISOLATED[cname] = cvalue;
    }

    function getCookie(cname)
    {
        if (ALLOWED_DOMAIN)
        {
            var name = cname + "=";
            var legacyName = cname + "_legacy=";
            var decodedCookie = decodeURIComponent(document.cookie);
            var ca = decodedCookie.split(';');
            for (var i = 0; i < ca.length; i++)
            {
                var c = ca[i];
                while (c.charAt(0) == ' ')
                {
                    c = c.substring(1);
                }
                if (c.indexOf(name) == 0)
                {
                    return c.substring(name.length, c.length);
                }
                if (c.indexOf(legacyName) == 0)
                {
                    return c.substring(legacyName.length, c.length);
                }
            }
            return null;
        } else return ISOLATED[cname] ? ISOLATED[cname] : null;
    }

    function getCookieKeys()
    {
        if (!ALLOWED_DOMAIN) return;
        var keys = [];
        if (document.cookie && document.cookie != '')
        {
            var split = document.cookie.split(';');
            for (var i = 0; i < split.length; i++)
            {
                var name_value = split[i].split("=");
                name_value[0] = name_value[0].replace(/^ /, '');
                keys.push(decodeURIComponent(name_value[0]));
            }
        }
        return cookies;
    }

    function removeCookie(cname)
    {
        if (ALLOWED_DOMAIN)
            document.cookie = cname + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
        else
            delete ISOLATED[cname];
    }

    function checkParentDomain(event)
    {
        // check parent domain
        var referrerDomain = event.origin ? event.origin.split('/').slice(0, 3).join('/') : 'no referrer';
        if (!window.ngappdata.domains)
            console.warn('CrossDomainStorage domains have not been set! Please set them in env.js!');
        else if (window.ngappdata.domains.indexOf(referrerDomain) === -1)
        {
            alert('Attempted to load the CrossDomainStorage from an unknown hostname! Please add the following domain to the platform env.js: ' + referrerDomain);
            ALLOWED_DOMAIN = false;
            setCookie("ADS_LASTSYNC", 1, 1);
            // Service will work with local ISOLATED data only 
        }
    }

    function receiveMessage(event)
    {
        checkParentDomain(event);

        var data = event.data;

        if (data && data.namespace === MESSAGE_NAMESPACE)
        {
            if (data.action === 'set')
            {
                setItem(data.id, data.key, data.value);
            }
            else if (data.action === 'setmulti')
            {
                setItems(data.id, data.key, data.value);
            }
            else if (data.action === 'get')
            {
                getItem(data.id, data.key);
            }
            else if (data.action === 'getmulti')
            {
                getItems(data.id, data.key);
            }
            else if (data.action === 'remove')
            {
                removeItem(data.id, data.key);
            }
            else if (data.action === 'removemulti')
            {
                removeItems(data.id, data.key);
            }
            else if (data.action === 'key')
            {
                getKey(data.id, data.value);
            }
            else if (data.action === 'size')
            {
                getSize(data.id);
            }
            else if (data.action === 'length')
            {
                getLength(data.id);
            }
            else if (data.action === 'clear')
            {
                clear(data.id);
            }
        }
    }

    function sendOnLoad()
    {
        var data = {
            namespace: MESSAGE_NAMESPACE,
            id: 'iframe-ready'
        };
        parent.postMessage(data, '*');
    }

    // ---- initialisation ----

    // add listeners
    if (window.addEventListener)
    {
        window.addEventListener('message', receiveMessage, false);
    }
    else
    {
        window.attachEvent('onmessage', receiveMessage);
    }

    // little hack to make sure cookies are loaded again (cookies have issues with tabs)
    if (hasToUseFallBack())
    {
        var fixSync = function ()
        {
            if (getCookie('ADS_LASTSYNC'))
                setCookie('ADS_LASTSYNC', parseInt(getCookie('ADS_LASTSYNC'), 10) + 1, 365);
        };
        setInterval(fixSync, 1000);
        fixSync();
    }

    sendOnLoad();
})();
