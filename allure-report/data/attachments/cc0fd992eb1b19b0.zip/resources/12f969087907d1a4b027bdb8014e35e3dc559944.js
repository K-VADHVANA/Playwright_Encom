window.ngappdata = window.ngappdata || {};
window.ngappdata.environmentName = "test";
window.ngappdata.systemCenterApiEndPoint = "https://api.test-enviso.io/systemcenterapi/";
window.ngappdata.scanningApiEndPoint = "https://api.test-enviso.io/scanningapi/";
window.ngappdata.reportDesignerApiEndPoint = "https://webshopdevtest.recreatex.be/";
window.ngappdata.reportCenterApiEndPoint = "https://api.test-enviso.io/reportingcenterapi/";
window.ngappdata.notificationCenterApiEndPoint = "https://api.test-enviso.io/notificationcenter/";
window.ngappdata.resellerCenterApiEndPoint = "https://api.test-enviso.io/resellercenterapi/";
window.ngappdata.offerCenterApiEndPoint = "https://api.test-enviso.io/offercenterapi/";
window.ngappdata.orderCenterApiEndPoint = "https://api.test-enviso.io/ordercenterapi/";
window.ngappdata.crmCenterApiEndPoint = "https://api.test-enviso.io/crmapi/";
window.ngappdata.paymentCenterApiEndpoint = "https://api.test-enviso.io/paymentcenterapi/";
window.ngappdata.salesChannelApiEndPoint = "https://api.test-enviso.io/saleschannelcenterapi/";
window.ngappdata.guideCenterApiEndPoint = "https://api.test-enviso.io/guidecenterapi/";
window.ngappdata.auditCenterApiEndPoint = 'https://api.test-enviso.io/auditcenterapi/';
window.ngappdata.webhookCenterApiEndPoint = "https://api.test-enviso.io/webhookcenterapi/";
window.ngappdata.formCenterApiEndpoint = "https://api.test-enviso.io/formcenterapi/";
window.ngappdata.webplatformAppUrl = "https://cloud.test-enviso.io/";
window.ngappdata.webSalesAppUrl = "https://sales.test-enviso.io/";
window.ngappdata.webeloxxAppUrl = "https://pay.test-enviso.io/";
window.ngappdata.webeloxxAppUrl = "https://eloxx.test-enviso.io/";
window.ngappdata.recaptchaSiteKey = "6LdeJz8UAAAAANdeN5TSARy7jX3b2OGTnbnlGDqT";
window.ngappdata.googleMapsApiKey = "AIzaSyCwfMa2FQ9ZMi2wVDA8hT_6s-wdBzMzgBg";
window.ngappdata.statuspalSubdomain = "gantner-com";
window.ngappdata.statuspalServiceId = "12995";
window.ngappdata.AdditionalFieldTenants = 1757;
window.ngappdata.encryptionPublicKey = "-----BEGIN PUBLIC KEY-----\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC6BRK9WIVZOsrK4rME7eudI6/e\no3eVljsIej5BqL9YNXpXxqGTIjlIvwAs+CgnPDFfNAd1GkNDNDsJcruWpH28uA15\nhK/IZVWnue0Hjws+8eJstwV7kDvV3nl35kZAUvqEKdo5XB91c//axt6zQ1+hJJrG\nrNyoncIam3zjTXYPlQIDAQAB\n-----END PUBLIC KEY-----";
window.ngappdata.domains = [
    "https://cloud.test-enviso.io",
    "https://trade.test-enviso.io",
    "https://sales.test-enviso.io",
    "https://booking.test-enviso.io",
    "https://console.test-enviso.io",
    "https://eloxx.test-enviso.io",
    "https://pay.test-enviso.io"
];
window.ngappdata.privacyPolicyUrl = 'https://gantner.com/en/privacy-policy';
window.ngappdata.fusionAuthLoginUrl = 'https://login.test-enviso.io/oauth2/authorize?client_id=912953ee-d6f6-4dcf-8ed3-9efc6aa52949&response_type=code&redirect_uri=https%3A%2F%2Fcloud.test-enviso.io%2Fcompletelogin&scope=openid+offline_access';
window.ngappdata.fusionAuthLogoutUrl = 'https://login.test-enviso.io/oauth2/logout?client_id=912953ee-d6f6-4dcf-8ed3-9efc6aa52949&post_logout_redirect_uri=https%3A%2F%2Fcloud.test-enviso.io%2Flogout';
